// bit_array.h
// Řešení IJC-DU1, příklad a), 21.3.2019
// Autor: David Rubý, FIT
// Přeloženo: gcc 7.3.0
// hlavičkový soubor pro soubor eratosthenes.c

#include "bit_array.h"

void Eratosthenes(bit_array_t pole);